package com.example.util.simpletimetracker.utils

@Retention(AnnotationRetention.RUNTIME)
annotation class Widget