repositories {
    google()
    jcenter()
}

plugins {
    `kotlin-dsl`
}