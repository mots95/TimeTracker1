package com.example.util.simpletimetracker

object Base {
    const val versionCode = 28
    const val versionName = "1.27"
    const val minSDK = 21
    const val currentSDK = 33
}
