package com.example.util.simpletimetracker.core.dialog

interface ChartFilterDialogListener {

    fun onChartFilterDialogDismissed()
}