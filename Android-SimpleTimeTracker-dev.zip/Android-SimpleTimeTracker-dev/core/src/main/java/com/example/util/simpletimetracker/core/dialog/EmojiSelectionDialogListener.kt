package com.example.util.simpletimetracker.core.dialog

interface EmojiSelectionDialogListener {

    fun onEmojiSelected(emojiText: String)
}