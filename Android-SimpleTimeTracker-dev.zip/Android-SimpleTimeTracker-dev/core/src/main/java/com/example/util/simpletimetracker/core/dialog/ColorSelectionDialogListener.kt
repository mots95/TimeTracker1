package com.example.util.simpletimetracker.core.dialog

interface ColorSelectionDialogListener {

    fun onColorSelected(colorInt: Int)
}