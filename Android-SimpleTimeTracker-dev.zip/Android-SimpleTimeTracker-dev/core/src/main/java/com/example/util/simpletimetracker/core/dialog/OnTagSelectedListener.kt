package com.example.util.simpletimetracker.core.dialog

interface OnTagSelectedListener {
    fun onTagSelected()
}